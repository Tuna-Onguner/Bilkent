import {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  matSelectAnimations
} from "./chunk-KBO3H3SP.js";
import "./chunk-NUYRNDIA.js";
import "./chunk-COQSKXXE.js";
import "./chunk-VLALGDFC.js";
import "./chunk-WBX25TY2.js";
import "./chunk-XVEOVXPC.js";
import "./chunk-NW3HEIWK.js";
import "./chunk-SXL7XPKM.js";
import "./chunk-A2OFGU6H.js";
import "./chunk-WTLPC6HK.js";
import "./chunk-VV2WFPAY.js";
import "./chunk-DMWQ5VCX.js";
import "./chunk-OXCW2X5T.js";
export {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  matSelectAnimations
};
//# sourceMappingURL=@angular_material_select.js.map
